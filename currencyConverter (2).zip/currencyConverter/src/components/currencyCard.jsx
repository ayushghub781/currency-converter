import React from 'react'

function CurrencyCard({
    label,
    amount=1,
    onAmountChange,
    selectCurrency="inr",
    currencyOptions = [],
    onCurrencyChange 
}) {
    return (
        <div className='w-fit mx-auto flex gap-3 my-4 bg-gray-400 p-3 rounded-lg'>
            <div className='flex flex-col gap-2'>
                <label>{label}</label>
                <input
                className=' bg-gray-400'
                    type='number'
                    value={amount}
                    onChange={(e)=>onAmountChange && onAmountChange(e.target.value)}
                />
            </div>
            <div className='flex flex-col gap-2'>
                <p>Currency type</p>
                <select className='bg-gray-400' value={selectCurrency} onChange={(e) => onCurrencyChange && onCurrencyChange(e.target.value)}>
                    {(currencyOptions).map((op) => (
                        <option key={op} value={op}>
                            {op}
                        </option>
                    ))}
                </select>
            </div>
        </div>
    )
}

export default CurrencyCard