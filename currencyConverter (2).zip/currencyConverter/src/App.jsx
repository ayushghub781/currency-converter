import { useEffect, useState } from 'react'
import './App.css'
import useCurrencyConvert from './hooks/useCurrencyConvert'
import CurrencyCard from './components/currencyCard'

function App() {
  const [amount,setAmount]= useState(1)
  const [from,setFrom] = useState("usd")
  const [to,setTO] = useState("inr")

  const options=useCurrencyConvert(from)

  const opt=Object.keys(options)

  const swap=()=>{
    setFrom(to)
    setTO(from)
  }
  

  return (
    <>
      <form onSubmit={(e)=>{e.preventDefault()}} className='w-fit mx-auto my-8 items-center flex flex-col'>
        <CurrencyCard
          label="From"
          amount={amount}
          onAmountChange={setAmount}
          selectCurrency={from}
          currencyOptions={opt}
          onCurrencyChange={setFrom}
        />
        <button onClick={swap} className='bg-blue-600 px-4 py-1 rounded-lg text-white'>Swap</button>
        <CurrencyCard
          label="To"
          amount={amount*options[to]}
          disabled={true}
          selectCurrency={to}
          currencyOptions={opt}
          onCurrencyChange={setTO}
        />
      </form>
    </>
  )
}

export default App
